x1 = [1 2 3 4.5 5.5 6 6.5 7 8 9];
x2 = [3 2 4 1 2.5 3 6 7 7 5];

hn = scatter(x1(1:end-4), x2(1:end-4), 50, 'b', 'filled');
hold on;
hp = scatter(x1(end-3:end), x2(end-3:end), 80, 'r+');
hu = scatter(x1([4:end-3 end]), x2([4:end-3 end]), 150, 'k');
legend([hp hn hu], 'positive', 'negative', 'unlabled', 'Location', 'NorthWest');

for i=1:length(x1)
    h = line([x1(i) x1(i)], [0 x2(i)]);
    set(h, 'LineStyle', ':');
    set(h, 'Color', 'k');
    h = line([0 x1(i)], [x2(i) x2(i)]);
    set(h, 'LineStyle', ':');
    set(h, 'Color', 'k');
end
hold off;
xlabel('feature 1');
ylabel('feature 2');
axis('equal');
xlim([0 10]);
ylim([0 8]);
saveas(h, 'hw7_3.png');


